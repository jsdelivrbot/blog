let myname : string = "wenbaofu";
let age : number = 30;

let temp = `my name is ${myname},I will be ${age + 1} next year`; 
console.log(temp);