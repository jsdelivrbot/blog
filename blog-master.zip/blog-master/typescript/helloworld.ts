function sayHello(name : string) : string
{
    return "hello" + name;
}

console.log(sayHello(",wenbaofu"));

