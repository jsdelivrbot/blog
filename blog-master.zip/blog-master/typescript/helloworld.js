function sayHello(name) {
    return "hello" + name;
}
console.log(sayHello(",wenbaofu"));
