var myname = "wenbaofu";
var age = 30;
var temp = "my name is " + myname + ",I will be " + (age + 1) + " next year";
console.log(temp);
