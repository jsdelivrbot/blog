///<reference path="node_modules/angular2/src/core/metadata.d.ts"/>
/**
 * Created by Administrator on 2016/10/30 0030.
 */
import { bootstrap } from 'angular2/platform/browser';
import { Component } from 'angular2/core';

@Component({
    selector : 'reddit',
    
})



