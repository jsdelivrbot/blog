
/*英雄类*/
export class Hero{
    id : number;
    name : string;
};